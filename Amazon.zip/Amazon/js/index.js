/**
 * Created by Karan on 16/6/11.
 */
    //页顶大广告
    $('#topAd').mouseover(function(){
        $('#allScreenAd').toggleClass('hide');

    });
    $('#allScreenAd .close').click(function(){
        $('#allScreenAd').toggleClass('hide');
    });
//轮播图上文字显示
$('#cateBanner').mouseover(function(){
    $('#cateBanner .model').css('display','block');
});
$('#cateBanner').mouseout(function(){
    $('#cateBanner .model').css('display','none');
});
var bg =["banner1.jpg","banner2.jpg","banner3.jpg","banner4.jpg","banner5.jpg"];
console.log(bg);
var bgIndex=0;

/***********  version:2 ***************/
function lunBo(index){
    $('#cateBanner').css('background','url("img/'+bg[index++]+'") no-repeat -270px 0');
    if(index == bg.length) index = 0;
    bgIndex = index;
}
var tim = setInterval(function(){
    lunBo(bgIndex);
},5000);
//轮播图按钮
$('#cateBanner .left').click(function(){
        console.log('click left 进来:'+bgIndex);
        if(bgIndex==0){
            bgIndex = bg.length;
        }
        bgIndex--;
        console.log('click left 出去:'+bgIndex);
        $('#cateBanner').css('background','url("img/'+bg[bgIndex]+'") no-repeat -270px 0');
    }
);
$('#cateBanner .right').click(function(){
        console.log('click right进来:'+ bgIndex);
        if(bgIndex==bg.length-1){
            bgIndex = -1;

        }
        bgIndex++;
        console.log('click right出去:'+ bgIndex);
        $('#cateBanner').css('background','url("img/'+bg[bgIndex]+'") no-repeat -270px 0');

    }
);
//细节图
    $('#forYou > .items >li').mouseover(function(){
        console.log( $(this).find('.rough'));
        $(this).find('.rough').css('visibility','hidden');
        $(this).find('.detail').css('display','block');
    });
    $('#forYou > .items >li>.detail').mouseout(function(){
        $(this).parent().find('.rough').css('visibility','visible');
        $(this).css('display','none');

    });

//全部商品列表
$('#cateBox>li>a').mouseenter(function(){
	$('div[data-catelist]').css('display','none');
	$(this).parent().find('div[data-catelist]').css('display','block');
});

$('div[data-catelist]').mouseleave(function(){
	$('div[data-catelist]').css('display','none');
});
